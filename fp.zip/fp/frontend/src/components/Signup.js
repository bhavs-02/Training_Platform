import React, { useState } from "react";
import Button from "react-bootstrap/Button";
import Form from "react-bootstrap/Form";
import Col from 'react-bootstrap/Col';
import Row from 'react-bootstrap/Row';
import { useNavigate } from 'react-router-dom';

const Signup = () => {
  const [formData, setFormData] = useState({
    username: '', 
    name: '',
    mail_id: '', 
    phone_number: '', 
    user_type: '', 
    password: '',
    creator_id: '' 
  });

  const handlebtn = (e) => {
    // Call both handleSubmit and handleNavigate functions
    handleSubmit(e);
    handleClick();
  };

  const handleClick = () => {
    // Navigate to the next page
    navigate('/login');
  };

  const navigate = useNavigate();

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prevState => ({
      ...prevState,
      [name]: value
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    console.log(formData);
  
    try {
      const response = await fetch('http://localhost:4000/signup', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(formData)
      });
  
      if (response.ok) {
        // Handle successful signup
        console.log('Signup successful');
        // Optionally, you can show a success message here
        navigate('/login'); // Navigate to login page
      } else {
        // Handle unsuccessful signup
        console.error('Signup failed');
        console.log(response);
        // Optionally, you can show an error message here
      }
    } catch (error) {
      console.error('An error occurred:', error);
      // Optionally, you can show an error message here
    }
  };

  return (
    <div className="card text-white bg-dark col-4 p-5">
      <Form onSubmit={handleSubmit}>
        <Row className="mb-3">
          <Form.Group as={Col} controlId="formGridName">
            <Form.Label>Name</Form.Label>
            <Form.Control 
              type="text" 
              name="name" 
              value={formData.name} 
              onChange={handleChange} 
              required 
              placeholder="Enter Name" 
            />
          </Form.Group>

          <Form.Group as={Col} controlId="formGridPassword">
            <Form.Label>Password</Form.Label>
            <Form.Control 
              type="password" 
              name="password" 
              value={formData.password} 
              onChange={handleChange} 
              required 
              placeholder="Set password" 
            />
          </Form.Group>
        </Row>

        <Form.Group controlId="formGridUsername">
            <Form.Label>Username</Form.Label>
            <Form.Control 
              type="text" 
              name="username" 
              value={formData.username} 
              onChange={handleChange} 
              required 
              placeholder="Enter username" 
            />
          </Form.Group>

        <Form.Group className="mb-3" controlId="formGridEmail">
          <Form.Label>Email</Form.Label>
          <Form.Control 
            type="email" 
            name="mail_id" // Changed to match the backend field name
            value={formData.mail_id} // Changed to match the backend field name
            onChange={handleChange} 
            placeholder="Enter email" 
          />
        </Form.Group>

        <Row className="mb-3">
          <Form.Group as={Col} className="mb-3" controlId="formGridMobile">
            <Form.Label>Phone Number</Form.Label>
            <Form.Control 
              type="tel" 
              name="phone_number" // Changed to match the backend field name
              value={formData.phone_number} // Changed to match the backend field name
              onChange={handleChange} 
              required 
              placeholder="+91 xxxxx xxxxx" 
            />
          </Form.Group>

          <Form.Group as={Col} controlId="formGridRole">
            <Form.Label>User Type</Form.Label>
            <Form.Select 
              name="user_type" // Changed to match the backend field name
              value={formData.user_type} // Changed to match the backend field name
              onChange={handleChange} 
              defaultValue="User Type"
            >
              <option disabled value="User Type">User Type</option>
              <option value="1">Admin</option>
              <option value="2">User</option>
            </Form.Select>
          </Form.Group>       
        </Row>

        <Form.Group className="mb-3" id="formGridCreator">
          <Form.Label>Creator ID</Form.Label>
          <Form.Control 
            type="number" 
            name="creator_id" // Changed to match the backend field name
            value={formData.creator_id} // Changed to match the backend field name
            onChange={handleChange} 
            placeholder="Enter creator ID" 
          />
        </Form.Group>

        <Button variant="primary" type="submit" onClick={handlebtn}>
          Submit
        </Button>
      </Form>
    </div>
  );
};

export default Signup;
