const express = require("express");
const cors = require("cors");
const port = 4000;

const app = express();
const pool = require("./db");

// middleware
app.use(express.json());
app.use(cors());

// Route to handle signup form submission
app.post('/signup', async (req, res) => {
  try {
    const { username, name, mail_id, phone_number, user_type, password, creator_id } = req.body;

    // Insert data into the database
    const result = await pool.query(
      'INSERT INTO users (username, name, mail_id, phone_number, user_type, password, creator_id) VALUES ($1, $2, $3, $4, $5, $6, $7) RETURNING id',
      [username, name, mail_id, phone_number, user_type, password, creator_id]
    );

    // Respond with success message or any other appropriate response
    res.status(201).json({ message: 'User signed up successfully', userId: result.rows[0].id });
  } catch (error) {
    console.error('Error occurred:', error);
    res.status(500).json({ message: 'An error occurred while processing your request' });
  }
});

//Login
// Add required imports
// const bcrypt = require('bcrypt');

// Route to handle login form submission
// Route to handle login form submission
app.post('/login', async (req, res) => {
  try {
    const { email, password, role } = req.body;

    // Fetch user from the database based on email
    const user = await pool.query('SELECT * FROM users WHERE mail_id = $1', [email]);

    // Check if user exists
    if (user.rows.length === 0) {
      return res.status(401).json({ error: 'User not found' });
    }

    // Verify password
    if (password !== user.rows[0].password) {
      return res.status(401).json({ error: 'Invalid password' });
    }

    // Check if user role matches
    if (user.rows[0].user_type !== parseInt(role)) {
      return res.status(401).json({ error: 'Unauthorized access' });
    }

    // Respond with success message or any other appropriate response
    res.status(200).json({ message: 'Login successful' });
  } catch (error) {
    console.error('An error occurred:', error);
    res.status(500).json({ message: 'An error occurred while processing your request' });
  }
});

app.get('/users', async (req, res) => {
  try {
    // Fetch all users from the database
    const users = await pool.query('SELECT * FROM users');

    // Respond with the retrieved users
    res.status(200).json(users.rows);
  } catch (error) {
    console.error('An error occurred:', error);
    res.status(500).json({ message: 'An error occurred while processing your request' });
  }
});


// Start the server
app.listen(port, () => {
  console.log(`Server is listening at http://localhost:${port}`);
});

  //ehfiohoifhe
// //endpoints
// app.post("/adduser",(req,res) => {
//     const username=req.body["username"]
//     const password=req.body["password"]
//     console.log("Username:"+username)
//     console.log("Password:"+password)

//     const insertSTMT=`INSERT INTO users (username,password) VALUES ('${username}','${password}');`
//     pool.query(insertSTMT).then((response)=>
//     {
//         console.log("data saved"),
//         console.log(response)
//     })
//     .catch((err)=>{
//         console.log(err);
//     });

//     console.log(req.body);
//     res.send("Response Received: "+req.body);
// } );

// app.listen(4000, () => console.log("server on localhost:4000"))
// //local


