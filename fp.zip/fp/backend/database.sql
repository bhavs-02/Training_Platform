-- Create the database (if it doesn't exist already)
CREATE DATABASE FinalProj;

-- Create the table
CREATE TABLE userdata(
    id INT PRIMARY KEY,
    name VARCHAR(255),
    mail_id VARCHAR(255),
    phone_number VARCHAR(15),
    user_type INT,
    password VARCHAR(255),
    creator_id INT
    
);

-- FOREIGN KEY (creator_id) REFERENCES YourTableName(id)
-- If you need to set constraints on mail_id and phone_number, you can add them like this:
-- ALTER TABLE YourTableName
-- ADD CONSTRAINT mail_unique UNIQUE (mail_id),
-- ADD CONSTRAINT phone_unique UNIQUE (phone_number);
