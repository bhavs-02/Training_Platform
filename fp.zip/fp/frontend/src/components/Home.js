import React from "react";
import Col from 'react-bootstrap/Col';
import Row from 'react-bootstrap/Row';
import Login from "./Login";
import Signup from "./Signup";

const Home = () => {
  return (
    <div className="p-5">
      <Row className="mb-3">
        <Signup as={Col} />
        <Col></Col>
        <Login as={Col} />
      </Row>
    </div>
  );
};

export default Home;
